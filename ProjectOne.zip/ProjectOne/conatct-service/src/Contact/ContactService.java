package Contact;

import java.util.ArrayList;
import java.util.UUID;

public class ContactService {

	public ArrayList<Contact> contactList = new ArrayList<Contact>();

	public void displayContactList() {
		for (int counter = 0; counter < contactList.size(); counter++) {
			System.out.println("\t Contact ID: " + contactList.get(counter).getContactID());
			System.out.println("\t First Name: " + contactList.get(counter).getFirstName());
			System.out.println("\t Last Name: " + contactList.get(counter).getLastName());
			System.out.println("\t Phone Number: " + contactList.get(counter).getNumber());
			System.out.println("\t Address: " + contactList.get(counter).getAddress() + "\n");
		}
	}

	public String addContact(String firstName, String lastName, String number, String address) {
	    String contactID = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
	    Contact contact = new Contact(contactID, firstName, lastName, number, address);
	    contactList.add(contact);
	    return contactID;
	}


	public Contact getContact(String contactID) {
		for (Contact contact : contactList) {
			if (contact.getContactID().equals(contactID)) {
				return contact;
			}
		}
		System.out.println("Contact ID: " + contactID + " not found.");
		return null;
	}

	public void deleteContact(String contactID) {
		for (int i = 0; i < contactList.size(); i++) {
			if (contactList.get(i).getContactID().equals(contactID)) {
				contactList.remove(i);
				return;
			}
		}
		System.out.println("Contact ID: " + contactID + " not found.");
	}

	public void updateFirstName(String updatedString, String contactID) {
		Contact contact = getContact(contactID);
		if (contact != null) {
			contact.setFirstName(updatedString);
		}
	}

	public void updateLastName(String updatedString, String contactID) {
		Contact contact = getContact(contactID);
		if (contact != null) {
			contact.setLastName(updatedString);
		}
	}

	public void updateNumber(String updatedString, String contactID) {
		Contact contact = getContact(contactID);
		if (contact != null) {
			contact.setNumber(updatedString);
		}
	}

	public void updateAddress(String updatedString, String contactID) {
		Contact contact = getContact(contactID);
		if (contact != null) {
			contact.setAddress(updatedString);
		}
	}
}
