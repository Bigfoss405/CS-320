package Test;

import Contact.ContactService;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

    @Test
    @DisplayName("Test to Update First Name.")
    @Order(1)
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        service.updateFirstName("Sven", contactID);
        assertEquals("Sven", service.getContact(contactID).getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Test to Update Last Name.")
    @Order(2)
    void testUpdateLastName() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        service.updateLastName("Shirley", contactID);
        assertEquals("Shirley", service.getContact(contactID).getLastName(), "Last name was not updated.");
    }

    @Test
    @DisplayName("Test to update phone number.")
    @Order(3)
    void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        service.updateNumber("5555550000", contactID);
        assertEquals("5555550000", service.getContact(contactID).getNumber(), "Phone number was not updated.");
    }

    @Test
    @DisplayName("Test to update address.")
    @Order(4)
    void testUpdateAddress() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        service.updateAddress("555 Nowhere Ave", contactID);
        assertEquals("555 Nowhere Ave", service.getContact(contactID).getAddress(), "Address was not updated.");
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes contacts.")
    @Order(5)
    void testDeleteContact() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        service.deleteContact(contactID);
        assertNull(service.getContact(contactID), "The contact was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that service can add a contact.")
    @Order(6)
    void testAddContact() {
        ContactService service = new ContactService();
        String contactID = service.addContact("Dr.", "Cross", "5555551111", "123 Lollypop Lane");
        assertNotNull(service.getContact(contactID), "Contact was not added correctly.");
    }
}
