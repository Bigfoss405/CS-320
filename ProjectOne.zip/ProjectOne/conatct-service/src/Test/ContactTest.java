package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import Contact.Contact;

public class ContactTest {

    @Test 
    @DisplayName("Contact ID cannot have more than 10 characters")
    void testContactIDWithMoreThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("12345678901", "FirstName", "LastName", "5555555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact First Name cannot have more than 10 characters")
    void testContactFirstNameWithMoreThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("1234567890", "OllyOllyOxenFree", "LastName", "5555555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact Last Name cannot have more than 10 characters")
    void testContactLastNameWithMoreThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("1234567890", "FirstName", "OllyOllyOxenFree", "5555555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact phone number must be exactly 10 characters")
    void testContactNumberWithInvalidLength() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("1234567890", "FirstName", "LastName", "55555555555", "Address")
        );
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("1234567890", "FirstName", "LastName", "55555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact address cannot have more than 30 characters")
    void testContactAddressWithMoreThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Contact("1234567890", "FirstName", "LastName", "5555555555", 
                        "1234567890123456789012345678901") // 31 characters
        );
    }

    @Test
    @DisplayName("Contact First Name shall not be null")
    void testContactFirstNameNotNull() {
        assertThrows(NullPointerException.class, () -> 
            new Contact("1234567890", null, "LastName", "5555555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact Last Name shall not be null")
    void testContactLastNameNotNull() {
        assertThrows(NullPointerException.class, () -> 
            new Contact("1234567890", "FirstName", null, "5555555555", "Address")
        );
    }

    @Test
    @DisplayName("Contact Phone Number shall not be null")
    void testContactPhoneNotNull() {
        assertThrows(NullPointerException.class, () -> 
            new Contact("1234567890", "FirstName", "LastName", null, "Address")
        );
    }

    @Test
    @DisplayName("Contact Address shall not be null")
    void testContactAddressNotNull() {
        assertThrows(NullPointerException.class, () -> 
            new Contact("1234567890", "FirstName", "LastName", "5555555555", null)
        );
    }
}