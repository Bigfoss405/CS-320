package com.foster.app.taskservice;

import java.util.ArrayList;
import java.util.List;

/**
 * TaskService manages a list of Task objects, allowing for creation,
 * retrieval, updates, deletion, and listing of tasks.
 */
public class TaskService {

    private final List<Task> taskList = new ArrayList<>();

    public void displayTaskList() {
        for (Task task : taskList) {
            System.out.println("\t Task ID: " + task.getTaskID());
            System.out.println("\t Task Name: " + task.getTaskName());
            System.out.println("\t Task Description: " + task.getTaskDesc());
        }
    }

    public void addTask(String taskName, String taskDesc) {
        taskList.add(new Task(taskName, taskDesc));
    }

    public Task getTask(String taskID) {
        for (Task task : taskList) {
            if (task.getTaskID().equals(taskID)) {
                return task;
            }
        }
        System.out.println("Task ID: " + taskID + " not found.");
        return null;
    }

    public void deleteTask(String taskID) {
        Task task = getTask(taskID);
        if (task != null) {
            taskList.remove(task);
        }
    }

    public void updateTaskName(String updatedName, String taskID) {
        Task task = getTask(taskID);
        if (task != null) {
            task.setTaskName(updatedName);
        }
    }

    public void updateTaskDesc(String updatedDesc, String taskID) {
        Task task = getTask(taskID);
        if (task != null) {
            task.setTaskDesc(updatedDesc);
        }
    }

    public List<Task> getTasks() {
        return new ArrayList<>(taskList);
    }
}
