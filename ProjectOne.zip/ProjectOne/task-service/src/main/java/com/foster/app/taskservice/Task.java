package com.foster.app.taskservice;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Represents a single task with a unique ID, name, and description.
 */
public class Task {

    private final String taskID;
    private String taskName;
    private String taskDesc;
    private static final AtomicLong idGenerator = new AtomicLong();

    public Task(String taskName, String taskDesc) {
        this.taskID = String.valueOf(idGenerator.getAndIncrement());
        setTaskName(taskName);
        setTaskDesc(taskDesc);
    }

    public String getTaskID() {
        return taskID;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskName(String taskName) {
        if (taskName == null || taskName.isEmpty()) {
            this.taskName = "NULL";
        } else {
            this.taskName = taskName.length() > 20 ? taskName.substring(0, 20) : taskName;
        }
    }

    public void setTaskDesc(String taskDesc) {
        if (taskDesc == null || taskDesc.isEmpty()) {
            this.taskDesc = "NULL";
        } else {
            this.taskDesc = taskDesc.length() > 50 ? taskDesc.substring(0, 50) : taskDesc;
        }
    }
}
