package com.foster.app.taskservice;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    @DisplayName("Task ID cannot have more than 10 characters")
    void testTaskIDWithMoreThanTenCharacters() {
        Task task = new Task("Name", "Description");
        assertTrue(task.getTaskID().length() <= 10, "Task ID has more than 10 characters.");
    }

    @Test
    @DisplayName("Task Name cannot have more than 20 characters")
    void testTaskNameWithMoreThanTwentyCharacters() {
        Task task = new Task("123456789012345678901", "Description");
        assertTrue(task.getTaskName().length() <= 20, "Task Name has more than 20 characters.");
    }

    @Test
    @DisplayName("Task Description cannot have more than 50 characters")
    void testTaskDescWithMoreThanFiftyCharacters() {
        Task task = new Task("Name", "123456789012345678901234567890123456789012345678901234567890");
        assertTrue(task.getTaskDesc().length() <= 50, "Task Description has more than 50 characters.");
    }

    @Test
    @DisplayName("Task Name shall not be null")
    void testTaskNameNotNull() {
        Task task = new Task(null, "Description");
        assertNotNull(task.getTaskName(), "Task Name was null.");
    }

    @Test
    @DisplayName("Task Description shall not be null")
    void testTaskDescNotNull() {
        Task task = new Task("Name", null);
        assertNotNull(task.getTaskDesc(), "Task Description was null.");
    }
}
