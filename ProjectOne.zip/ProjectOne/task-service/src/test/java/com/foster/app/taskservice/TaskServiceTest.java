package com.foster.app.taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    @DisplayName("Test to update task name")
    @Order(1)
    void testUpdateTaskName() {
        TaskService service = new TaskService();
        service.addTask("Task Name", "Description");
        String taskId = service.getTasks().get(0).getTaskID();
        service.updateTaskName("Updated Task Name", taskId);
        assertEquals("Updated Task Name", service.getTask(taskId).getTaskName());
    }

    @Test
    @DisplayName("Test to update task description")
    @Order(2)
    void testUpdateTaskDesc() {
        TaskService service = new TaskService();
        service.addTask("Task Name", "Description");
        String taskId = service.getTasks().get(0).getTaskID();
        service.updateTaskDesc("Updated Description", taskId);
        assertEquals("Updated Description", service.getTask(taskId).getTaskDesc());
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes tasks")
    @Order(5)
    void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask("Task Name", "Description");
        String taskId = service.getTasks().get(0).getTaskID();
        service.deleteTask(taskId);
        assertNull(service.getTask(taskId), "The task was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that service can add a task")
    @Order(6)
    void testAddTask() {
        TaskService service = new TaskService();
        service.addTask("Task Name", "Description");
        assertFalse(service.getTasks().isEmpty(), "Task was not added correctly.");
    }
}
