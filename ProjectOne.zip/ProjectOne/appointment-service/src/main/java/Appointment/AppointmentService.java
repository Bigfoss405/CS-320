package Appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	public ArrayList<Appointment> appointmentList = new ArrayList<>();

	// Display all appointments in the console
	public void displayAppointmentList() {
		for (Appointment a : appointmentList) {
			System.out.println("\tAppointment ID: " + a.getAppointmentID());
			System.out.println("\tAppointment Date: " + a.getAppointmentDate());
			System.out.println("\tAppointment Description: " + a.getAppointmentDesc());
		}
	}

	// Add a new appointment and return its ID
	public String addAppointment(Date date, String desc) {
		Appointment appt = new Appointment(date, desc);
		appointmentList.add(appt);
		return appt.getAppointmentID();
	}

	// Retrieve appointment by ID, returns null if not found
	public Appointment getAppointment(String appointmentID) {
		for (Appointment a : appointmentList) {
			if (a.getAppointmentID().equals(appointmentID)) {
				return a;
			}
		}
		return null;
	}

	// Delete appointment by ID
	public void deleteAppointment(String appointmentID) {
		boolean removed = appointmentList.removeIf(a -> a.getAppointmentID().equals(appointmentID));
		if (!removed) {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
		}
	}

	// Update appointment date by ID
	public void updateAppointmentDate(Date updatedDate, String appointmentID) {
		Appointment a = getAppointment(appointmentID);
		if (a != null) {
			a.setAppointmentDate(updatedDate);
		} else {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
		}
	}

	// Update appointment description by ID
	public void updateAppointmentDesc(String updatedDesc, String appointmentID) {
		Appointment a = getAppointment(appointmentID);
		if (a != null) {
			a.setAppointmentDesc(updatedDesc);
		} else {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
		}
	}
}
