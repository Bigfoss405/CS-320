package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

	@Test
	@DisplayName("Appointment ID cannot have more than 10 characters")
	void testAppointmentIDWithMoreThanTenCharacters() {
		Date futureDate = new GregorianCalendar(3025, Calendar.JANUARY, 1).getTime();
		Appointment appointment = new Appointment(futureDate, "Description");
		assertTrue(appointment.getAppointmentID().length() <= 10, "Appointment ID has more than 10 characters.");
	}

	@Test
	@DisplayName("Task Description cannot have more than 50 characters")
	void testAppointmentDescWithMoreThanFiftyCharacters() {
		Date futureDate = new GregorianCalendar(3025, Calendar.JANUARY, 1).getTime();
		String longDesc = "This description exceeds the 50 character limit definitely.";
		Appointment appointment = new Appointment(futureDate, longDesc);
		assertTrue(appointment.getAppointmentDesc().length() <= 50, "Appointment Description has more than 50 characters.");
	}

	@Test
	@DisplayName("Appointment Date cannot be before current date")
	void testAppointmentDateBeforeCurrent() {
		Date pastDate = new GregorianCalendar(1022, Calendar.JANUARY, 1).getTime();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(pastDate, "Description");
		}, "Expected exception for past date was not thrown.");
	}

	@Test
	@DisplayName("Appointment Date shall not be null")
	void testAppointmentDateNotNull() {
		Appointment appointment = new Appointment(null, "Description");
		assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null.");
	}

	@Test
	@DisplayName("Appointment Description shall not be null")
	void testAppointmentDescNotNull() {
		Date futureDate = new GregorianCalendar(3025, Calendar.JANUARY, 1).getTime();
		Appointment task = new Appointment(futureDate, null);
		assertNotNull(task.getAppointmentDesc(), "Appointment Description was null.");
	}
}
