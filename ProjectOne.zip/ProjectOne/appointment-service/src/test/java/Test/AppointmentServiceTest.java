package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;

class AppointmentServiceTest {

	@Test
	@DisplayName("Test to Update appointment date")
	@Order(1)
	void testUpdateAppointmentDate() {
		AppointmentService service = new AppointmentService();
		Date originalDate = new GregorianCalendar(3035, Calendar.JANUARY, 1).getTime();
		String id = service.addAppointment(originalDate, "Description"); // capture ID

		Date newDate = new GregorianCalendar(3036, Calendar.FEBRUARY, 2).getTime();
		service.updateAppointmentDate(newDate, id);

		assertEquals(newDate, service.getAppointment(id).getAppointmentDate(), "Appointment date was not updated.");
	}

	@Test
	@DisplayName("Test to Update appointment description.")
	@Order(2)
	void testUpdateAppointmentDesc() {
		AppointmentService service = new AppointmentService();
		String id = service.addAppointment(new GregorianCalendar(2030, Calendar.JANUARY, 1).getTime(), "Description");
		service.updateAppointmentDesc("Updated Description", id);
		assertEquals("Updated Description", service.getAppointment(id).getAppointmentDesc(), "Appointment description was not updated.");
	}

	@Test
	@DisplayName("Test to ensure that service correctly deletes appointments.")
	@Order(3)
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		String id = service.addAppointment(new GregorianCalendar(2030, Calendar.JANUARY, 1).getTime(), "Description");
		service.deleteAppointment(id);
		assertNull(service.getAppointment(id), "The appointment was not deleted.");
	}

	@Test
	@DisplayName("Test to ensure that service can add an appointment.")
	@Order(4)
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		String id = service.addAppointment(new GregorianCalendar(2030, Calendar.JANUARY, 1).getTime(), "Description");
		assertNotNull(service.getAppointment(id), "Appointment was not added correctly.");
	}
}
